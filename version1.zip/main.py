import os
import json
import time
import requests
import httpx
from flask import Flask, request, jsonify
from flask_cors import CORS
# NOTE: Removed 'from dotenv import load_dotenv' and 'load_dotenv()' as per the new implementation structure.
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
# Switching to the base ChatOpenAI class to allow custom base_url
from langchain_openai import ChatOpenAI

app = Flask(__name__)
CORS(app) # Enable CORS for frontend communication

# Setup httpx client with SSL verification disabled (like in testkey.py)
client = httpx.Client(verify=False)

# --- Configuration for TCS Gen AI Lab MAAS ---

# 1. Custom Base URL
TCS_MAAS_BASE_URL = "https://genailab.tcs.in" 

# 2. Deployment names for your specific models (matching HTML options exactly)
MODEL_MAPPING = {
    "gpt-4o": "azure/genailab-maas-gpt-4o",
    "gpt-35-turbo": "azure/genailab-maas-gpt-35-turbo",
    "llama-3-70b": "azure_ai/genailab-maas-Llama-3.3-70B-Instruct",
    "phi-4-reasoning": "azure_ai/genailab-maas-Phi-4-reasoning",
    "gpt-4o-mini": "azure/genailab-maas-gpt-4o-mini",
    "deepseek-v3": "azure_ai/genailab-maas-DeepSeek-V3-0324",
}
DEFAULT_MODEL_KEY = "gpt-4o"

# --- LangChain Components ---

# 1. System Prompt Template
SYSTEM_PROMPT = """
You are a Senior Data Engineer and an expert communicator. Your task is to analyze the provided ANOMALY ALERT and the PIPELINE METADATA. Synthesize this technical information into a concise, professional, two-paragraph summary suitable for non-technical leadership (e.g., Product Manager, VP of Operations).

Follow this strict structure:
Paragraph 1 (Impact & Cause): State the immediate business impact, the severity, and the technical root cause derived from the alert and metadata.
Paragraph 2 (Action Plan): Propose the immediate next step for the On-Call Engineer, referencing the required team and system to contact for resolution.
"""

# 2. Function to Initialize LLM (Model Router)
def get_llm_instance(model_key):
    """
    Initializes the ChatOpenAI instance with the custom TCS MAAS base_url.
    
    Uses the same configuration as testkey.py for consistency.
    """
    deployment_name = MODEL_MAPPING.get(model_key, MODEL_MAPPING[DEFAULT_MODEL_KEY])
    
    # Initialize ChatOpenAI with the custom base_url and model name (matching testkey.py)
    llm = ChatOpenAI(
        base_url="https://genailab.tcs.in",
        model=deployment_name,  # Use the mapped model name
        api_key="sk-bo6iKxEh5xAMVYNzF9sEYg",  # Same API key as testkey.py
        http_client=client,  # Use the httpx client with SSL verification disabled
        temperature=0.1
    )
    return llm


def call_llm_chain(model_key, anomaly_alert, pipeline_metadata):
    """
    Constructs the LangChain chain and executes the LLM call.
    """
    try:
        llm = get_llm_instance(model_key)

        # 2. User Prompt Template (Input variables will be filled by data)
        user_template = """
--- ANOMALY ALERT LOG ---
{anomaly_alert_json}

--- PIPELINE METADATA ---
{pipeline_metadata_json}
"""
        
        # 3. Create the Prompt Template
        prompt = ChatPromptTemplate.from_messages([
            ("system", SYSTEM_PROMPT),
            ("human", user_template),
        ])

        # 4. Define the Chain (Prompt | LLM | Output Parser)
        chain = prompt | llm | StrOutputParser()

        # 5. Invoke the Chain with Data
        response = chain.invoke({
            "anomaly_alert_json": json.dumps(anomaly_alert, indent=2),
            "pipeline_metadata_json": json.dumps(pipeline_metadata, indent=2),
        })

        return response.strip()

    except Exception as e:
        # Catch LLM/API errors within the chain execution
        print(f"LangChain/LLM Chain Execution Error: {e}")
        return None


@app.route('/generate_explanation', methods=['POST'])
def generate_explanation_endpoint():
    """
    Flask endpoint to receive anomaly data and trigger the LangChain process.
    """
    try:
        data = request.json
        anomaly_alert = data.get('anomalyAlert', {})
        pipeline_metadata = data.get('pipelineMetadata', {})
        selected_model_key = data.get('selectedModel', DEFAULT_MODEL_KEY)
        
        if not anomaly_alert or not pipeline_metadata:
            return jsonify({"error": "Missing anomaly alert or pipeline metadata in request."}), 400

        # Pass the data and model key to the LangChain wrapper
        explanation_text = call_llm_chain(selected_model_key, anomaly_alert, pipeline_metadata)

        if not explanation_text:
            return jsonify({"error": "Failed to generate explanation. Check server logs."}), 500

        return jsonify({"explanation": explanation_text})

    except ValueError as ve:
        # Catch explicit missing environment variable errors from get_llm_instance
        print(f"Configuration Error: {ve}")
        return jsonify({"error": f"Configuration Error: {str(ve)}"}), 500
    except Exception as e:
        print(f"Internal server error in Flask endpoint: {e}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)