import os
import json
import time
import requests
import httpx
import hashlib
import sqlite3
import asyncio
from datetime import datetime
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
from cachetools import TTLCache
import tiktoken

# Document processing imports
import PyPDF2
from docx import Document
import io

# LangChain imports
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI
from langchain_text_splitters import RecursiveCharacterTextSplitter

app = Flask(__name__)
CORS(app) # Enable CORS for frontend communication

# Setup httpx client with SSL verification disabled (like in testkey.py)
client = httpx.Client(verify=False)

# Enhanced caching and analytics system
response_cache = TTLCache(maxsize=500, ttl=7200)  # 2-hour cache for responses
content_hash_cache = TTLCache(maxsize=200, ttl=3600)  # 1-hour for content hashes
processed_documents = {}

# Cost and performance tracking
analytics = {
    "total_requests": 0,
    "cache_hits": 0,
    "total_tokens": 0,
    "estimated_costs": 0.0,
    "processing_times": [],
    "model_usage": defaultdict(int)
}

# Thread pool for background processing
executor = ThreadPoolExecutor(max_workers=4)

# Configure file upload settings
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'doc', 'docx'}
MAX_FILE_SIZE = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# --- Configuration for TCS Gen AI Lab MAAS ---

# 1. Custom Base URL
TCS_MAAS_BASE_URL = "https://genailab.tcs.in" 

# 2. Deployment names for your specific models (matching HTML options exactly)
MODEL_MAPPING = {
    "gpt-4o": "azure/genailab-maas-gpt-4o",
    "gpt-35-turbo": "azure/genailab-maas-gpt-35-turbo",
    "llama-3-70b": "azure_ai/genailab-maas-Llama-3.3-70B-Instruct",
    "phi-4-reasoning": "azure_ai/genailab-maas-Phi-4-reasoning",
    "gpt-4o-mini": "azure/genailab-maas-gpt-4o-mini",
    "deepseek-v3": "azure_ai/genailab-maas-DeepSeek-V3-0324",
}
DEFAULT_MODEL_KEY = "gpt-4o"

# --- Vector Database Setup ---
# Initialize embeddings and vector store
# Use OpenAI embeddings instead to avoid SSL issues with HuggingFace
# For now, we'll use a simple fallback approach
embeddings = None
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
    length_function=len,
)

# Simple in-memory document store (fallback solution)
document_store = []
vector_store = None

def initialize_simple_store():
    """Initialize simple document storage"""
    global document_store
    document_store = []
    print("Initialized simple document store")
    
initialize_simple_store()

# --- Document Processing Functions ---

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text_from_pdf(file_content):
    """Extract text from PDF file"""
    try:
        pdf_reader = PyPDF2.PdfReader(io.BytesIO(file_content))
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"
        return text
    except Exception as e:
        raise Exception(f"Error processing PDF: {str(e)}")

def extract_text_from_docx(file_content):
    """Extract text from DOCX file"""
    try:
        doc = Document(io.BytesIO(file_content))
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        return text
    except Exception as e:
        raise Exception(f"Error processing DOCX: {str(e)}")

def extract_text_from_txt(file_content):
    """Extract text from TXT file"""
    try:
        return file_content.decode('utf-8')
    except UnicodeDecodeError:
        try:
            return file_content.decode('latin-1')
        except Exception as e:
            raise Exception(f"Error processing TXT file: {str(e)}")

def process_document(filename, file_content):
    """Process uploaded document and return extracted text"""
    file_extension = filename.rsplit('.', 1)[1].lower()
    
    if file_extension == 'pdf':
        return extract_text_from_pdf(file_content)
    elif file_extension in ['doc', 'docx']:
        return extract_text_from_docx(file_content)
    elif file_extension == 'txt':
        return extract_text_from_txt(file_content)
    else:
        raise Exception(f"Unsupported file type: {file_extension}")

def get_file_hash(file_content):
    """Generate hash for file content to enable caching"""
    return hashlib.md5(file_content).hexdigest()

def count_tokens(text, model="gpt-4"):
    """Count tokens in text using tiktoken"""
    try:
        # Handle model name variations
        model_name = model.replace('-', '_')
        if 'azure' in model or 'genailab' in model:
            model_name = 'gpt-4'  # Default for Azure models
        encoding = tiktoken.encoding_for_model(model_name)
        return len(encoding.encode(text))
    except:
        # Fallback: approximate token count
        return int(len(text.split()) * 1.3)

def optimize_content_for_model(content, model_key, max_tokens=4000):
    """Intelligently truncate content to stay within token limits"""
    try:
        model_name = model_key.replace('-', '_')
        if 'azure' in model_key or 'genailab' in model_key:
            model_name = 'gpt-4'
        
        encoding = tiktoken.encoding_for_model(model_name)
        tokens = encoding.encode(content)
        
        if len(tokens) <= max_tokens:
            return content
        
        # Smart truncation - keep beginning and end, summarize middle
        start_tokens = tokens[:max_tokens//3]
        end_tokens = tokens[-(max_tokens//3):]
        
        start_text = encoding.decode(start_tokens)
        end_text = encoding.decode(end_tokens)
        
        return f"{start_text}\n\n[Middle content truncated - {len(tokens)-max_tokens} tokens removed for cost optimization]\n\n{end_text}"
        
    except Exception as e:
        print(f"Token optimization error: {e}")
        # Fallback to character-based estimation
        char_limit = max_tokens * 3  # Rough estimation
        if len(content) <= char_limit:
            return content
        return content[:char_limit//2] + "\n\n[Content truncated for cost optimization]\n\n" + content[-char_limit//2:]

def count_request_tokens(prompt, content, model_key):
    """Count total tokens for cost estimation"""
    total_text = f"{prompt}\n{content}"
    return count_tokens(total_text, model_key)

def select_optimal_model(content_size, analysis_type="standard"):
    """Select most cost-effective model based on request complexity"""
    token_count = count_tokens(content_size)
    
    if token_count < 1000 and analysis_type == "simple":
        return "gpt-4o-mini"  # Cheapest for simple tasks
    elif token_count < 4000:
        return "gpt-35-turbo"  # Good balance of cost/quality
    else:
        return "gpt-4o"  # Best quality for complex analysis

def estimate_cost(model_key, input_tokens, output_tokens=500):
    """Estimate API cost for transparency"""
    # Approximate costs per 1K tokens (update with actual pricing)
    costs = {
        "gpt-4o": {"input": 0.03, "output": 0.06},
        "gpt-35-turbo": {"input": 0.0015, "output": 0.002},
        "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
    }
    
    # Extract base model name for cost calculation
    base_model = "gpt-4o"
    if "gpt-35" in model_key or "turbo" in model_key:
        base_model = "gpt-35-turbo"
    elif "mini" in model_key:
        base_model = "gpt-4o-mini"
    
    model_cost = costs.get(base_model, costs["gpt-4o"])
    total_cost = ((input_tokens / 1000) * model_cost["input"]) + ((output_tokens / 1000) * model_cost["output"])
    return total_cost

def get_request_hash(model_key, content, analysis_type):
    """Generate unique hash for request to enable caching"""
    cache_key = f"{model_key}:{analysis_type}:{hashlib.md5(content.encode()).hexdigest()}"
    return cache_key

def get_cached_response(cache_key):
    """Check if we have a cached response"""
    return response_cache.get(cache_key)

def cache_response(cache_key, response):
    """Cache the LLM response"""
    response_cache[cache_key] = response
    print(f"Cached response for key: {cache_key[:20]}...")

def track_request(model_key, tokens, cost, processing_time, cache_hit=False):
    """Track request metrics for optimization"""
    analytics["total_requests"] += 1
    analytics["total_tokens"] += tokens
    analytics["estimated_costs"] += cost
    analytics["processing_times"].append(processing_time)
    analytics["model_usage"][model_key] += 1
    
    if cache_hit:
        analytics["cache_hits"] += 1

def search_relevant_context(query, max_chunks=5):
    """Search document store for relevant context using simple text matching"""
    if not document_store:
        return []
    
    try:
        # Enhanced keyword-based search with scoring
        query_words = [word.lower() for word in query.split() if len(word) > 2]  # Ignore short words
        scored_chunks = []
        
        for doc in document_store:
            chunk_text = doc['content'].lower()
            score = 0
            
            # Count matches and give higher scores for exact phrase matches
            for word in query_words:
                if word in chunk_text:
                    score += chunk_text.count(word)
            
            if score > 0:
                scored_chunks.append((score, doc['content']))
        
        # Sort by score (highest first) and return top chunks
        scored_chunks.sort(key=lambda x: x[0], reverse=True)
        relevant_chunks = [chunk[1] for chunk in scored_chunks[:max_chunks]]
        
        print(f"Searched {len(document_store)} chunks, found {len(relevant_chunks)} relevant ones")
        return relevant_chunks
    except Exception as e:
        print(f"Error searching document store: {e}")
        return []

# --- LangChain Components ---

# Optimized prompts for cost efficiency
OPTIMIZED_SYNTHETIC_PROMPT = """Analyze anomaly alert and provide:
1. IMPACT & CAUSE: Business impact, severity, root cause
2. ACTION PLAN: Immediate steps, team contacts, resolution guidance
Be concise and actionable."""

OPTIMIZED_LOG_PROMPT = """Analyze this log data and provide:
1. SUMMARY: What happened and severity
2. IMPACT: Business/system effects  
3. ROOT CAUSE: Technical reason
4. ACTIONS: Immediate next steps
5. PREVENTION: How to avoid recurrence
Be concise and actionable."""

# Legacy prompt for backward compatibility
SYSTEM_PROMPT = OPTIMIZED_SYNTHETIC_PROMPT

# 2. Function to Initialize LLM (Model Router)
def get_llm_instance(model_key):
    """
    Initializes the ChatOpenAI instance with the custom TCS MAAS base_url.
    
    Uses the same configuration as testkey.py for consistency.
    """
    deployment_name = MODEL_MAPPING.get(model_key, MODEL_MAPPING[DEFAULT_MODEL_KEY])
    
    # Initialize ChatOpenAI with the custom base_url and model name (matching testkey.py)
    llm = ChatOpenAI(
        base_url="https://genailab.tcs.in",
        model=deployment_name,  # Use the mapped model name
        api_key="sk-bo6iKxEh5xAMVYNzF9sEYg",  # Same API key as testkey.py
        http_client=client,  # Use the httpx client with SSL verification disabled
        temperature=0.1
    )
    return llm


def call_llm_chain_with_log_data(model_key, log_data):
    """
    Process uploaded log data and generate explanation using LLM with optimization.
    """
    try:
        start_time = time.time()
        
        # Optimize content for cost efficiency
        optimized_log_data = optimize_content_for_model(log_data, model_key, max_tokens=3500)
        
        # Count tokens for cost tracking
        input_tokens = count_request_tokens(OPTIMIZED_LOG_PROMPT, optimized_log_data, model_key)
        estimated_cost = estimate_cost(model_key, input_tokens)
        
        print(f"Processing log data - Tokens: {input_tokens}, Estimated cost: ${estimated_cost:.4f}")
        
        llm = get_llm_instance(model_key)
        
        # User prompt template for log data
        user_template = """
Analyze this log data:

--- LOG DATA ---
{log_data}

Provide structured analysis as requested.
"""
        
        # Create the Prompt Template with optimized prompt
        prompt = ChatPromptTemplate.from_messages([
            ("system", OPTIMIZED_LOG_PROMPT),
            ("human", user_template),
        ])

        # Define the Chain (Prompt | LLM | Output Parser)
        chain = prompt | llm | StrOutputParser()

        # Invoke the Chain with optimized data
        response = chain.invoke({
            "log_data": optimized_log_data,
        })

        # Track performance metrics
        processing_time = time.time() - start_time
        track_request(model_key, input_tokens, estimated_cost, processing_time)
        
        return response.strip()

    except Exception as e:
        print(f"LangChain/LLM Chain Execution Error with log data: {e}")
        return None

def call_llm_chain_with_synthetic_data(model_key, anomaly_alert, pipeline_metadata):
    """
    Process synthetic anomaly data and generate explanation using LLM with optimization.
    """
    try:
        start_time = time.time()
        
        # Prepare content for token counting
        content = f"{json.dumps(anomaly_alert, indent=2)}\n{json.dumps(pipeline_metadata, indent=2)}"
        input_tokens = count_request_tokens(OPTIMIZED_SYNTHETIC_PROMPT, content, model_key)
        estimated_cost = estimate_cost(model_key, input_tokens)
        
        print(f"Processing synthetic data - Tokens: {input_tokens}, Estimated cost: ${estimated_cost:.4f}")
        
        llm = get_llm_instance(model_key)

        # User Prompt Template for synthetic data
        user_template = """
Alert: {anomaly_alert_json}
Metadata: {pipeline_metadata_json}
"""
        
        # Create the Prompt Template with optimized prompt
        prompt = ChatPromptTemplate.from_messages([
            ("system", OPTIMIZED_SYNTHETIC_PROMPT),
            ("human", user_template),
        ])

        # Define the Chain (Prompt | LLM | Output Parser)
        chain = prompt | llm | StrOutputParser()

        # Invoke the Chain with Data
        response = chain.invoke({
            "anomaly_alert_json": json.dumps(anomaly_alert, indent=2),
            "pipeline_metadata_json": json.dumps(pipeline_metadata, indent=2),
        })

        # Track performance metrics
        processing_time = time.time() - start_time
        track_request(model_key, input_tokens, estimated_cost, processing_time)
        
        return response.strip()

    except Exception as e:
        print(f"LangChain/LLM Chain Execution Error with synthetic data: {e}")
        return None


@app.route('/upload_log_data', methods=['POST'])
def upload_log_data():
    """
    Handle file uploads and process them as primary input data for analysis
    """
    try:
        if 'files' not in request.files:
            return jsonify({"error": "No files provided"}), 400
        
        files = request.files.getlist('files')
        if not files or all(file.filename == '' for file in files):
            return jsonify({"error": "No files selected"}), 400
        
        combined_content = ""
        processed_files = []
        
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_content = file.read()
                
                # Check file size
                if len(file_content) > MAX_FILE_SIZE:
                    processed_files.append({
                        'filename': filename,
                        'status': 'error',
                        'error': 'File too large'
                    })
                    continue
                
                try:
                    # Extract text from document
                    text_content = process_document(filename, file_content)
                    
                    if text_content.strip():
                        combined_content += f"\n--- {filename} ---\n{text_content}\n"
                        processed_files.append({
                            'filename': filename,
                            'status': 'processed',
                            'size': len(text_content)
                        })
                    else:
                        processed_files.append({
                            'filename': filename,
                            'status': 'error',
                            'error': 'No text content found'
                        })
                
                except Exception as e:
                    print(f"Error processing {filename}: {e}")
                    processed_files.append({
                        'filename': filename,
                        'status': 'error',
                        'error': str(e)
                    })
        
        if not combined_content.strip():
            return jsonify({"error": "No valid content extracted from files"}), 400
        
        return jsonify({
            "message": "Log files processed successfully",
            "log_content": combined_content.strip(),
            "processed_files": processed_files
        })
    
    except Exception as e:
        print(f"Error in upload_log_data: {e}")
        return jsonify({"error": f"Upload failed: {str(e)}"}), 500

@app.route('/generate_explanation', methods=['POST'])
def generate_explanation_endpoint():
    """
    Optimized Flask endpoint with caching, cost tracking, and performance monitoring.
    """
    try:
        request_start_time = time.time()
        data = request.json
        selected_model_key = data.get('selectedModel', DEFAULT_MODEL_KEY)
        use_uploaded_data = data.get('useUploadedData', False)
        log_data = data.get('logData', '')
        
        print(f"Processing request - Use uploaded data: {use_uploaded_data}, Log data length: {len(log_data) if log_data else 0}")
        
        # Generate cache key for request
        analysis_type = "log_analysis" if use_uploaded_data else "synthetic_analysis"
        content_for_hash = log_data if use_uploaded_data else f"{data.get('anomalyAlert', {})}{data.get('pipelineMetadata', {})}"
        cache_key = get_request_hash(selected_model_key, content_for_hash, analysis_type)
        
        # Check cache first
        cached_result = get_cached_response(cache_key)
        if cached_result:
            print("Returning cached response - saved LLM cost!")
            total_processing_time = time.time() - request_start_time
            track_request(selected_model_key, 0, 0.0, total_processing_time, cache_hit=True)
            
            return jsonify({
                **cached_result,
                "cached": True,
                "processing_time": f"{total_processing_time:.2f}s",
                "cost_saved": True
            })
        
        # Process request
        if use_uploaded_data and log_data and log_data.strip():
            print("Using uploaded log data for analysis")
            
            # Auto-optimize model selection for cost efficiency
            optimal_model = select_optimal_model(log_data, "complex")
            if optimal_model != selected_model_key:
                print(f"Recommending model optimization: {selected_model_key} -> {optimal_model}")
            
            explanation_text = call_llm_chain_with_log_data(selected_model_key, log_data)
            
            # Calculate metrics
            input_tokens = count_request_tokens(OPTIMIZED_LOG_PROMPT, log_data, selected_model_key)
            estimated_cost = estimate_cost(selected_model_key, input_tokens)
            
            response_data = {
                "explanation": explanation_text,
                "data_source": "uploaded_logs",
                "data_type": "real_log_analysis",
                "log_size": len(log_data),
                "tokens_used": input_tokens,
                "estimated_cost": f"${estimated_cost:.4f}",
                "optimized_model_suggestion": optimal_model if optimal_model != selected_model_key else None
            }
        else:
            # Fallback to synthetic data
            print("Falling back to synthetic data")
            anomaly_alert = data.get('anomalyAlert', {})
            pipeline_metadata = data.get('pipelineMetadata', {})
            
            if not anomaly_alert or not pipeline_metadata:
                return jsonify({"error": "No uploaded data available and missing synthetic data in request."}), 400
            
            explanation_result = call_llm_chain_with_synthetic_data(selected_model_key, anomaly_alert, pipeline_metadata)
            
            # Calculate metrics
            content = f"{json.dumps(anomaly_alert)}{json.dumps(pipeline_metadata)}"
            input_tokens = count_request_tokens(OPTIMIZED_SYNTHETIC_PROMPT, content, selected_model_key)
            estimated_cost = estimate_cost(selected_model_key, input_tokens)
            
            response_data = {
                "explanation": explanation_result,
                "data_source": "synthetic_data",
                "data_type": "demo_analysis",
                "tokens_used": input_tokens,
                "estimated_cost": f"${estimated_cost:.4f}"
            }
        
        if not response_data["explanation"]:
            return jsonify({"error": "Failed to generate explanation. Check server logs."}), 500

        # Cache the response for future use
        cache_response(cache_key, response_data)
        
        # Add processing time
        total_processing_time = time.time() - request_start_time
        response_data["processing_time"] = f"{total_processing_time:.2f}s"
        response_data["cached"] = False
        
        return jsonify(response_data)

    except Exception as e:
        print(f"Internal server error in Flask endpoint: {e}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500

@app.route('/analytics', methods=['GET'])
def get_analytics():
    """Endpoint to monitor cost and performance metrics"""
    avg_processing_time = sum(analytics["processing_times"]) / len(analytics["processing_times"]) if analytics["processing_times"] else 0
    cache_hit_rate = (analytics["cache_hits"] / analytics["total_requests"]) * 100 if analytics["total_requests"] else 0
    
    return jsonify({
        "total_requests": analytics["total_requests"],
        "cache_hit_rate": f"{cache_hit_rate:.1f}%",
        "total_tokens": analytics["total_tokens"],
        "estimated_total_costs": f"${analytics['estimated_costs']:.4f}",
        "avg_processing_time": f"{avg_processing_time:.2f}s",
        "model_usage": dict(analytics["model_usage"]),
        "cost_savings_from_cache": f"${(analytics['cache_hits'] * 0.002):.4f}",
        "cache_entries": len(response_cache),
        "optimization_recommendations": {
            "cache_performance": "Excellent" if cache_hit_rate > 60 else "Good" if cache_hit_rate > 30 else "Needs Improvement",
            "avg_tokens_per_request": int(analytics["total_tokens"] / analytics["total_requests"]) if analytics["total_requests"] else 0,
            "cost_efficiency": "Optimized" if avg_processing_time < 2.0 else "Standard"
        }
    })

@app.route('/optimize/clear-cache', methods=['POST'])
def clear_cache():
    """Clear response cache for testing and maintenance"""
    global response_cache, content_hash_cache
    cache_size_before = len(response_cache)
    response_cache.clear()
    content_hash_cache.clear()
    
    return jsonify({
        "message": "Cache cleared successfully",
        "entries_cleared": cache_size_before
    })

@app.route('/optimize/model-recommendations', methods=['POST'])
def get_model_recommendations():
    """Get model recommendations based on content analysis"""
    try:
        data = request.json
        content = data.get('content', '')
        current_model = data.get('currentModel', 'gpt-4o')
        
        # Analyze content complexity
        token_count = count_tokens(content)
        optimal_model = select_optimal_model(content, "standard")
        current_cost = estimate_cost(current_model, token_count)
        optimal_cost = estimate_cost(optimal_model, token_count)
        savings = current_cost - optimal_cost
        
        return jsonify({
            "current_model": current_model,
            "recommended_model": optimal_model,
            "token_count": token_count,
            "current_estimated_cost": f"${current_cost:.4f}",
            "optimized_estimated_cost": f"${optimal_cost:.4f}",
            "potential_savings": f"${savings:.4f}" if savings > 0 else "$0.0000",
            "savings_percentage": f"{(savings/current_cost)*100:.1f}%" if current_cost > 0 and savings > 0 else "0%",
            "recommendation": "Switch to recommended model" if optimal_model != current_model else "Current model is optimal"
        })
        
    except Exception as e:
        return jsonify({"error": f"Error generating recommendations: {str(e)}"}), 500

@app.route('/debug/documents', methods=['GET'])
def debug_documents():
    """Debug endpoint to check stored documents"""
    return jsonify({
        "document_count": len(document_store),
        "documents": [{"source": doc.get("source", "unknown"), "chunk_id": doc.get("chunk_id", "unknown"), "content_preview": str(doc.get("content", ""))[:100] + "..."} for doc in document_store[:5]] if document_store else [],
        "cache_status": {
            "response_cache_size": len(response_cache),
            "content_hash_cache_size": len(content_hash_cache)
        }
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)