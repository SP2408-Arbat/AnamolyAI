import os
import json
import time
import requests
import httpx
import hashlib
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
from cachetools import TTLCache
import tiktoken

# Document processing imports
import PyPDF2
from docx import Document
import io

# LangChain imports
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI
from langchain_text_splitters import RecursiveCharacterTextSplitter

app = Flask(__name__)
CORS(app) # Enable CORS for frontend communication

# Setup httpx client with SSL verification disabled (like in testkey.py)
client = httpx.Client(verify=False)

# Initialize caching and document processing
document_cache = TTLCache(maxsize=100, ttl=3600)  # Cache for 1 hour
processed_documents = {}

# Configure file upload settings
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'doc', 'docx'}
MAX_FILE_SIZE = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# --- Configuration for TCS Gen AI Lab MAAS ---

# 1. Custom Base URL
TCS_MAAS_BASE_URL = "https://genailab.tcs.in" 

# 2. Deployment names for your specific models (matching HTML options exactly)
MODEL_MAPPING = {
    "gpt-4o": "azure/genailab-maas-gpt-4o",
    "gpt-35-turbo": "azure/genailab-maas-gpt-35-turbo",
    "llama-3-70b": "azure_ai/genailab-maas-Llama-3.3-70B-Instruct",
    "phi-4-reasoning": "azure_ai/genailab-maas-Phi-4-reasoning",
    "gpt-4o-mini": "azure/genailab-maas-gpt-4o-mini",
    "deepseek-v3": "azure_ai/genailab-maas-DeepSeek-V3-0324",
}
DEFAULT_MODEL_KEY = "gpt-4o"

# --- Vector Database Setup ---
# Initialize embeddings and vector store
# Use OpenAI embeddings instead to avoid SSL issues with HuggingFace
# For now, we'll use a simple fallback approach
embeddings = None
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
    length_function=len,
)

# Simple in-memory document store (fallback solution)
document_store = []
vector_store = None

def initialize_simple_store():
    """Initialize simple document storage"""
    global document_store
    document_store = []
    print("Initialized simple document store")
    
initialize_simple_store()

# --- Document Processing Functions ---

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text_from_pdf(file_content):
    """Extract text from PDF file"""
    try:
        pdf_reader = PyPDF2.PdfReader(io.BytesIO(file_content))
        text = ""
        for page in pdf_reader.pages:
            text += page.extract_text() + "\n"
        return text
    except Exception as e:
        raise Exception(f"Error processing PDF: {str(e)}")

def extract_text_from_docx(file_content):
    """Extract text from DOCX file"""
    try:
        doc = Document(io.BytesIO(file_content))
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        return text
    except Exception as e:
        raise Exception(f"Error processing DOCX: {str(e)}")

def extract_text_from_txt(file_content):
    """Extract text from TXT file"""
    try:
        return file_content.decode('utf-8')
    except UnicodeDecodeError:
        try:
            return file_content.decode('latin-1')
        except Exception as e:
            raise Exception(f"Error processing TXT file: {str(e)}")

def process_document(filename, file_content):
    """Process uploaded document and return extracted text"""
    file_extension = filename.rsplit('.', 1)[1].lower()
    
    if file_extension == 'pdf':
        return extract_text_from_pdf(file_content)
    elif file_extension in ['doc', 'docx']:
        return extract_text_from_docx(file_content)
    elif file_extension == 'txt':
        return extract_text_from_txt(file_content)
    else:
        raise Exception(f"Unsupported file type: {file_extension}")

def get_file_hash(file_content):
    """Generate hash for file content to enable caching"""
    return hashlib.md5(file_content).hexdigest()

def count_tokens(text, model="gpt-4"):
    """Count tokens in text using tiktoken"""
    try:
        encoding = tiktoken.encoding_for_model(model)
        return len(encoding.encode(text))
    except:
        # Fallback: approximate token count
        return len(text.split()) * 1.3

def search_relevant_context(query, max_chunks=5):
    """Search document store for relevant context using simple text matching"""
    if not document_store:
        return []
    
    try:
        # Enhanced keyword-based search with scoring
        query_words = [word.lower() for word in query.split() if len(word) > 2]  # Ignore short words
        scored_chunks = []
        
        for doc in document_store:
            chunk_text = doc['content'].lower()
            score = 0
            
            # Count matches and give higher scores for exact phrase matches
            for word in query_words:
                if word in chunk_text:
                    score += chunk_text.count(word)
            
            if score > 0:
                scored_chunks.append((score, doc['content']))
        
        # Sort by score (highest first) and return top chunks
        scored_chunks.sort(key=lambda x: x[0], reverse=True)
        relevant_chunks = [chunk[1] for chunk in scored_chunks[:max_chunks]]
        
        print(f"Searched {len(document_store)} chunks, found {len(relevant_chunks)} relevant ones")
        return relevant_chunks
    except Exception as e:
        print(f"Error searching document store: {e}")
        return []

# --- LangChain Components ---

# 1. System Prompt Template (Updated to include document context)
SYSTEM_PROMPT = """
You are a Senior Data Engineer and an expert communicator. Your task is to analyze the provided ANOMALY ALERT and PIPELINE METADATA. You may also be provided with additional DOCUMENT CONTEXT from uploaded files to enhance your analysis. Synthesize this technical information into a concise, professional, two-paragraph summary suitable for non-technical leadership (e.g., Product Manager, VP of Operations).

Follow this strict structure:
Paragraph 1 (Impact & Cause): State the immediate business impact, the severity, and the technical root cause derived from the alert and metadata. If document context is provided, incorporate relevant insights.
Paragraph 2 (Action Plan): Propose the immediate next step for the On-Call Engineer, referencing the required team and system to contact for resolution. Use document context to provide more specific guidance if available.
"""

# 2. Function to Initialize LLM (Model Router)
def get_llm_instance(model_key):
    """
    Initializes the ChatOpenAI instance with the custom TCS MAAS base_url.
    
    Uses the same configuration as testkey.py for consistency.
    """
    deployment_name = MODEL_MAPPING.get(model_key, MODEL_MAPPING[DEFAULT_MODEL_KEY])
    
    # Initialize ChatOpenAI with the custom base_url and model name (matching testkey.py)
    llm = ChatOpenAI(
        base_url="https://genailab.tcs.in",
        model=deployment_name,  # Use the mapped model name
        api_key="sk-bo6iKxEh5xAMVYNzF9sEYg",  # Same API key as testkey.py
        http_client=client,  # Use the httpx client with SSL verification disabled
        temperature=0.1
    )
    return llm


def call_llm_chain_with_log_data(model_key, log_data):
    """
    Process uploaded log data and generate explanation using LLM.
    """
    try:
        llm = get_llm_instance(model_key)
        
        # Updated system prompt for log analysis
        log_analysis_prompt = """
You are a Senior Data Engineer and expert log analyst. Your task is to analyze the provided LOG DATA and create a clear, professional explanation suitable for technical and non-technical stakeholders.

Please analyze the logs and provide:

1. **Summary**: What type of system/application this log is from and what it shows
2. **Key Findings**: Important events, errors, patterns, or anomalies found in the logs
3. **Impact Assessment**: Potential impact on system performance, users, or business operations
4. **Recommendations**: Specific actionable steps to address any issues found

Be concise but thorough. Focus on the most critical information that stakeholders need to know.
"""
        
        # User prompt template for log data
        user_template = """
Please analyze the following log data:

--- LOG DATA ---
{log_data}

Please provide a structured analysis as requested in the instructions.
"""
        
        # Create the Prompt Template
        prompt = ChatPromptTemplate.from_messages([
            ("system", log_analysis_prompt),
            ("human", user_template),
        ])

        # Define the Chain (Prompt | LLM | Output Parser)
        chain = prompt | llm | StrOutputParser()

        # Truncate log data if too long to stay within token limits
        max_log_length = 8000  # Adjust based on model limits
        if len(log_data) > max_log_length:
            log_data = log_data[:max_log_length] + "\n\n[Log data truncated due to length...]"

        # Invoke the Chain with Log Data
        response = chain.invoke({
            "log_data": log_data,
        })

        return response.strip()

    except Exception as e:
        print(f"LangChain/LLM Chain Execution Error with log data: {e}")
        return None

def call_llm_chain_with_synthetic_data(model_key, anomaly_alert, pipeline_metadata):
    """
    Process synthetic anomaly data and generate explanation using LLM.
    """
    try:
        llm = get_llm_instance(model_key)

        # User Prompt Template for synthetic data
        user_template = """
--- ANOMALY ALERT LOG ---
{anomaly_alert_json}

--- PIPELINE METADATA ---
{pipeline_metadata_json}
"""
        
        # Create the Prompt Template
        prompt = ChatPromptTemplate.from_messages([
            ("system", SYSTEM_PROMPT),
            ("human", user_template),
        ])

        # Define the Chain (Prompt | LLM | Output Parser)
        chain = prompt | llm | StrOutputParser()

        # Invoke the Chain with Data
        response = chain.invoke({
            "anomaly_alert_json": json.dumps(anomaly_alert, indent=2),
            "pipeline_metadata_json": json.dumps(pipeline_metadata, indent=2),
        })

        return response.strip()

    except Exception as e:
        print(f"LangChain/LLM Chain Execution Error with synthetic data: {e}")
        return None


@app.route('/upload_log_data', methods=['POST'])
def upload_log_data():
    """
    Handle file uploads and process them as primary input data for analysis
    """
    try:
        if 'files' not in request.files:
            return jsonify({"error": "No files provided"}), 400
        
        files = request.files.getlist('files')
        if not files or all(file.filename == '' for file in files):
            return jsonify({"error": "No files selected"}), 400
        
        combined_content = ""
        processed_files = []
        
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_content = file.read()
                
                # Check file size
                if len(file_content) > MAX_FILE_SIZE:
                    processed_files.append({
                        'filename': filename,
                        'status': 'error',
                        'error': 'File too large'
                    })
                    continue
                
                try:
                    # Extract text from document
                    text_content = process_document(filename, file_content)
                    
                    if text_content.strip():
                        combined_content += f"\n--- {filename} ---\n{text_content}\n"
                        processed_files.append({
                            'filename': filename,
                            'status': 'processed',
                            'size': len(text_content)
                        })
                    else:
                        processed_files.append({
                            'filename': filename,
                            'status': 'error',
                            'error': 'No text content found'
                        })
                
                except Exception as e:
                    print(f"Error processing {filename}: {e}")
                    processed_files.append({
                        'filename': filename,
                        'status': 'error',
                        'error': str(e)
                    })
        
        if not combined_content.strip():
            return jsonify({"error": "No valid content extracted from files"}), 400
        
        return jsonify({
            "message": "Log files processed successfully",
            "log_content": combined_content.strip(),
            "processed_files": processed_files
        })
    
    except Exception as e:
        print(f"Error in upload_log_data: {e}")
        return jsonify({"error": f"Upload failed: {str(e)}"}), 500

@app.route('/generate_explanation', methods=['POST'])
def generate_explanation_endpoint():
    """
    Flask endpoint to generate explanations from either uploaded log data or synthetic data.
    """
    try:
        data = request.json
        selected_model_key = data.get('selectedModel', DEFAULT_MODEL_KEY)
        use_uploaded_data = data.get('useUploadedData', False)
        log_data = data.get('logData', '')
        
        if use_uploaded_data and log_data:
            # Use uploaded log data as primary input
            explanation_text = call_llm_chain_with_log_data(selected_model_key, log_data)
            response_data = {
                "explanation": explanation_text,
                "data_source": "uploaded_logs"
            }
        else:
            # Use synthetic data as fallback
            anomaly_alert = data.get('anomalyAlert', {})
            pipeline_metadata = data.get('pipelineMetadata', {})
            
            if not anomaly_alert or not pipeline_metadata:
                return jsonify({"error": "Missing input data in request."}), 400
            
            explanation_result = call_llm_chain_with_synthetic_data(selected_model_key, anomaly_alert, pipeline_metadata)
            response_data = {
                "explanation": explanation_result,
                "data_source": "synthetic_data"
            }
        
        if not response_data["explanation"]:
            return jsonify({"error": "Failed to generate explanation. Check server logs."}), 500

        return jsonify(response_data)

    except Exception as e:
        print(f"Internal server error in Flask endpoint: {e}")
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500

@app.route('/debug/documents', methods=['GET'])
def debug_documents():
    """Debug endpoint to check stored documents"""
    return jsonify({
        "document_count": len(document_store),
        "documents": [{"source": doc["source"], "chunk_id": doc["chunk_id"], "content_preview": doc["content"][:100] + "..."} for doc in document_store[:5]]
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)